<?php

  require_once("../include/common.inc");

  $wo_id=$_GET['wo_id'];

//  include ("https://".$common->get_frontend_server."/".$server['fqdn']."appmgmt/getWorkorderDetails.php?wo_id=".$wo_id.urlencode($path));
  include ("https://dev60z6.ghx.com:7860/appmgmt/getWorkorderDetails.php?wo_id=".$wo_id);

  function do_post($dp_woid,$dp_action,$dp_msg) {

    $dp_result = include("https://dev60z6.ghx.com:7860/appmgmt/logClientAction.php?wo_id=".$dp_woid."&action=".$dp_action."&message=".urlencode($dp_msg));
    return 1;

  }

  $fph = popen($_WO_DETAIL['wod']['script']." ".$_WO_DETAIL['wod']['args'] , "r");
  while (!feof($fph)) {
    $results = fgets($fph, 4096);
    if ($results) {
      list($action , $data) = split(":" , $results , 2);
      $data = chop($data);
      do_post($wo_id,$action,$data);
    }
  }
  pclose($fph);


?>
