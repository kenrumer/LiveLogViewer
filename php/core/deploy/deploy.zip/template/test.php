<?php

  echo "\"../include/class.".PHP_OS.".inc\"";

?>