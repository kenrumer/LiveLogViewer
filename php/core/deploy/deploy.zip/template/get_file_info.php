<?php

  require_once("../include/common.inc");
  require_once("../include/explorer.inc");

  $common = new common();
  $explorer = new explorer();

  $path = $common->get_query_string($_GET, 'path');

  echo ("<?php\n");

  $perms = substr(decoct(fileperms($path)), 3);
  echo ("\$perms = \"".$perms."\"".';'."\n");
  $attribs = stat($path);
  echo ("\$attribs = ");
  var_export($attribs);
  echo (';'."\n");
  $file_size = $attribs['size'];
  echo ("\$file_size = \"".$file_size."\"".';'."\n");
  $line_count = $explorer->line_count($path);
  echo ("\$line_count = \"".$line_count."\"".';'."\n");
  $md5 = md5_file($path);
  echo ("\$md5 = \"".$md5."\"".';'."\n");
  $basename = basename($path);
  echo ("\$basename = \"".$basename."\"".';'."\n");

  echo ('?>');
?>
