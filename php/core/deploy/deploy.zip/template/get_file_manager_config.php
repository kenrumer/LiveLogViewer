<?php

  require_once("../include/common.inc");
  require_once("../include/explorer.inc");

  $common = new common();
  $explorer = new explorer();

  $ret_array = array();

  if (file_exists("C:\\Program Files\\php\\etc\\logadm.conf")) {
    $handle = fopen("C:\\Program Files\\php\\etc\\logadm.conf", "r");
  }

  if ($handle) {
    while (!feof($handle)) {
      $buffer = fgets($handle);
      $buffer = trim($buffer);
      if ($buffer[0] != "#") {
        $argv = split('[[:space:]]+', $buffer);
        $options = common->getopt($argv, "abcdefghijklmnop");
        $opts = $options[0];
        $non_opts = $options[1];
        $i = 0;
        print "options: ";
        foreach ($opts as $o => $d) {
          if ($i++ > 0) {
            print ", ";
          }
          print $d[0] . '=' . $d[1];
        }
        print "\n";
        print "params: " . implode(", ", $non_opts) . "\n";
        print "\n";
      }
    }
  }
  exit(0);      

  echo ('<?php $_CONFIGS[\''.$common->get_hostname().'\'] = ');
  echo (var_export($ret_array)."; ?>\n");

?>
