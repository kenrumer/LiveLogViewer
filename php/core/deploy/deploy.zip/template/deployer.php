<?php

  require_once("../include/common.inc");
  require_once("../include/explorer.inc");

  $common = new common();
  $explorer = new explorer();

  $path = getcwd();
  $path_parts = split('[\\\/]', $path);
  array_pop($path_parts);
  $parent = implode('/', $path_parts);

  copy("https://".$_SERVER['SERVER_NAME']."/deploy/deploy.zip", "deploy.zip");
  $zip_file = new ZipArchive;
  $res = $zip_file->open("deploy.zip");
  if ($res === TRUE) {
    $zip_file->extractTo($parent);
    $zip_file->close();
  } else {
    echo ("ERROR");
    exit(0);
  }

  unlink("deploy.zip");

?>
    <div id="<?php echo($common->get_hostname()) ?>">
      <a href="javascript:deploy_display_results('<?php echo($common->get_hostname()); ?>files');"><?php echo($common->get_hostname()) ?></a>
      <div style="display:none" id="<?php echo($common->get_hostname()) ?>files">
<?php
  $filelist = array();
  if(is_dir($path)) {
    $dh = @opendir($path);
    while (false !== ($file = @readdir($dh))) {
      if (is_file($path."/".$file) && (false == ereg("^\.", $file))) {
        $filelist[] = $file;
      }
    }
  }
  sort($filelist);
  foreach ($filelist as $file) {
    $attribs = stat($path."/".$file);
    $perms = substr(decoct(fileperms($path."/".$file)), 3);
?>
        <div id="<?php echo($common->get_hostname().$file); ?>">
          <div style="float:left;width:80px">
            <?php echo($perms); ?>

          </div>
          <div style="float:left;width:80px">
            <?php echo($attribs['nlink']); ?>

          </div>
<?php
      if ($attribs['uid'] != 0) {
?>
          <div style="float:left;width:80px">
            <?php echo($attribs['uid']); ?>

          </div>
          <div style="float:left;width:80px">
            <?php echo($attribs['gid']); ?>

          </div>
<?php
      }
?>
          <div style="float:left;width:80px">
            <?php echo ($explorer->byte_convert($attribs['size'])); ?>

          </div>
          <div style="float:left;width:180px">
            <?php echo (strftime("%m/%d/%Y %H:%M:%S", $attribs['mtime'])); ?>

          </div>
          <div style="width:80px">
            <?php echo ($file); ?>

          </div>
        </div>
<?php
  }
?>
      </div>
    </div>
