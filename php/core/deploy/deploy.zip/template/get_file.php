<?php

  require_once("../include/common.inc");

  $common = new common();

  $path = $common->get_query_string($_GET, 'path');

  $file_size = filesize($path);

  if ($file_size > $common->get_limit()) {
    $fh = fopen ($path, "r");
    fseek($fh, $file_size-$common->get_limit());
    echo (htmlentities(fread($fh, $common->get_limit())));
    fclose($fh);
  } else {
    echo (htmlentities(file_get_contents($path)));
  }

?>
