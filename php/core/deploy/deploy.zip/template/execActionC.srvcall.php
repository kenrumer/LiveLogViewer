<?php

  require_once("../include/common.inc");

  $wo_id=$_GET['wo_id'];

<?php

  require_once("../include/common.inc");

  $wo_id=$_GET['wo_id'];

  include ("https://".urlencode($session->get("user_name", "node_php")).":".urlencode($session->get("passwd","node_php"))."@".$frontend_server."/".$se
rver['fqdn']."../usr/bin/getWorkorderDetails.php?wo_id=".$wo_id..urlencode($path));

  var_dump($wo_details);

//  $fph = popen($script." ".$arguments , "r");
//  while (!feof($fph)) {
//    $results = fgets($fph, 4096);
//    if ($results) {
//      echo($results);
//    }
//  }
//  pclose($fph);



?>
